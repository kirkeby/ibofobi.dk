/*
 * libportalfs.c -- user-space implementation of BSD's portal-fs.
 * Copyright (C) 2001 by Sune Kirkeby <sune@interspace.dk>.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 *      Overview
 *      ========
 *
 * This library is a proof-of-concept for a user-space implementation of
 * the 4.4BSD portalfs described in [BSD].  The inspiration to try
 * something like this came while the author was reading [OO], despite
 * the fact that the paper is not directly related to the subject at
 * hand. Inspiration for the actual implementation came from the
 * fakeroot Debian package (FIXME -- Need an URL here.)
 *
 * The library works by intercepting calls to open(2), and handling
 * paths with special prefixes (e.g. "/tcp") internally.  Attempts
 * to open(2) all other paths are passed along down the shared-object
 * chain (or passed along to libc if this is not supported.)
 *
 * The actual interception is done when actually executing a program,
 * where the LD_PRELOAD environment variable must be set to point
 * to the libportalfs shared-object.  This forces the Linux [other
 * UNIX-systems with shared-object support do this also, or?] dynamic
 * linker to link the executable against symbols from this library
 * before those from libc are considered.
 *
 *      Comparison w/ the 4.4BSD portalfs
 *      =================================
 *
 * Pros:
 * 
 * This approach to implementing 4.4BSD portalfs-like behavior has
 * several pros.  Firstly it is fairly simple to implement and debug, as
 * opposed to the 4.4BSD portalfs which required modifications to be
 * made to the 4.4BSD kernel (this reflects the authors personal
 * feelings, and should be taken as such.)
 *
 * Secondly, it allows users to implement and use their own portals,
 * without needing any special privileges.  This is in stark contrast
 * to the 4.4BSD portalfs, which requires kernel support and special
 * daemons.
 *
 * Lastly, libportalfs can [I suspect, anyway :-] be ported to any
 * UNIX-like operating system, which supports shared objects.  It could
 * of course also be ported to operating systems which do not support
 * shared objects, but it's greatest virtue (that it requires no
 * relinking or recompilation of applications) would then be lost.
 *
 * Cons:
 *      
 * There are several reasons why the 4.4BSD method is more complete,
 * and thus better in some circumstances, they all follow from the
 * fact that the kernel is not in on the tricks played on the
 * applications.
 *
 * Firstly, this of course mean that things break down in the fringe
 * cases. This includes suid and sgid binaries, for which the dynamic
 * linker does _not_ honour the LD_PRELOAD environment variable.  Also,
 * any program which calls the kernel directly will not have it's
 * open(2) calls intercepted (technically it makes no open(2) calls,
 * just system calls,) so it is useless to protect against hostile
 * applications which know of it's existence.
 *
 * Secondly, if the wrapper-library is implementing portalfs-like
 * behavior, where new pseudo directory-structures are created (e.g.
 * "/tcp"), any external inspection of the programs state will be
 * inconsistent with what the program itself experiences (unless it
 * itself does external inspections of itself :-).
 *
 * Undoubtably something important has been forgotten here, apologies
 * in advance.
 *
 *		References
 *		==========
 *
 * o [BSD] ``Portals in 4.4BSD'' 
 *         W. Richard Stevens and Jan-Simon Pendry
 *         http://www.kohala.com/start/portals.ps
 * o [OO]  ``Inheritance in Unlikely Places: Using Objects to Build
 *           Derived Implementations of Flat Interfaces''
 *         Michael B. Jones.
 *
 * -- Sune Kirkeby, 3. june 2001.
 */

/* Need this to get RTLD_NEXT from dlfcn.h, */
#define _GNU_SOURCE

#include <dlfcn.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define min(a, b) ((a) > (b) ? (b) : (a))

/* External symbol aliases (initialized from load_symbols), */
typedef int (*open_function)(const char *file, int oflag, mode_t mode);
open_function real_open;
open_function real_open64;

/* Get handle for libc (or next in chain of libc-wrappers,) */
#ifdef RTLD_NEXT
#   define dlopen_libc() (RTLD_NEXT)
#else
#   define LIBC_PATH "/lib/libc.so.6"
void *dlopen_libc()
{
    void *libc = dlopen(LIBC_PATH, RTLD_LAZY);
    if(! libc) {
        fprintf(stderr, "libportalfs: %s\n", dlerror());
        exit(1);
    }
    return libc;
}
#endif

/* Initializes all external symbol aliases, */
void load_symbols()
{
    static int inited = 0;
    void *libc;

    if(inited)
        return;

    libc = dlopen_libc();
    real_open = dlsym(libc, "open");
    real_open64 = dlsym(libc, "open64");
    inited = 1;
}

/* Helpder functions, */
const char *extract_hostname(const char *proto, const char *path)
{
    static char hostname[NI_MAXHOST]; /* FIXME -- clearly wrong! */
    char *c = strchr(path, '/');
    if(! c) {
        return 0;
    } else {
        strncpy(hostname, path, min(sizeof(hostname) - 1, c - path));
        hostname[sizeof(hostname) - 1] = 0;
    }
    return hostname;
}
int extract_port(const char *proto, const char *path)
{
    struct servent *serv;
    char *service;
    char *end;
    long port;

    service = strchr(path, '/');
    if(! service) {
        return 0;
    }
    service = service + 1;
    
    port = strtol(service, &end, 0);
    if(*end == 0) {
        if((port > 0) && (port < 65536)) {
            return port;
        } else {
            return -1;
        }
    }

    serv = getservbyname(service, proto);
    if(serv) {
        return serv->s_port;
    }

    return -1;
}
const struct sockaddr *resolve_address(const char *proto,
                                       const char *path, socklen_t *len)
{
    static struct sockaddr_in addr;
    const char *hostname = extract_hostname(proto, path);
    int port = extract_port(proto, path);

    if((hostname == 0) || (port < 0)) {
        return 0;
    }
    
    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    if(inet_pton(addr.sin_family, hostname, &addr) < 0) {
        return 0;
    }
    addr.sin_port = port;
    *len = sizeof(addr);

    return (const struct sockaddr *) &addr;
}

int open_tcp(const char *file)
{
    const struct sockaddr *serv_addr;
    socklen_t addrlen;
    int fd;

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd < 0) {
        return fd;
    }

    serv_addr = resolve_address("tcp", file + 5, &addrlen);
    if(serv_addr == 0) {
        close(fd);
        return -1;
    }
    if(connect(fd, serv_addr, addrlen)) {
        close(fd);
        return -1;
    }

    return fd;
}

/* Wrapper functions, */
int _open(const char *file, int oflag, mode_t mode, open_function real_open)
{
    load_symbols();
    if(strncmp(file, "/tcp/", 5) == 0) {
        return open_tcp(file);
    } else {
        return real_open(file, oflag, mode);
    }
}
int open(const char *file, int oflag, mode_t mode)
{
    return _open(file, oflag, mode, real_open);
}
int open64(const char *file, int oflag, mode_t mode)
{
    return _open(file, oflag, mode, real_open64);
}
